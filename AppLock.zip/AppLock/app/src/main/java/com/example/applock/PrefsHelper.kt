package com.example.applock

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.MessageDigest

/**
 * Central place for everything App Lock needs to remember:
 *  - which package names are locked
 *  - the PIN (stored only as a salted hash, never in plain text)
 *  - a short grace period after a correct unlock so the accessibility
 *    service doesn't immediately re-lock the app you just opened
 */
object PrefsHelper {

    private const val REGULAR_PREFS = "app_lock_prefs"
    private const val SECURE_PREFS = "app_lock_secure_prefs"

    private const val KEY_LOCKED_PACKAGES = "locked_packages"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_UNLOCK_UNTIL_PREFIX = "unlock_until_"

    // How long an app stays unlocked after a correct PIN before it needs to be re-entered
    private const val GRACE_PERIOD_MS = 5000L

    private fun regularPrefs(context: Context): SharedPreferences =
        context.getSharedPreferences(REGULAR_PREFS, Context.MODE_PRIVATE)

    private fun securePrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        return EncryptedSharedPreferences.create(
            context,
            SECURE_PREFS,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // ---------- Locked package management ----------

    fun getLockedPackages(context: Context): MutableSet<String> =
        HashSet(regularPrefs(context).getStringSet(KEY_LOCKED_PACKAGES, emptySet()) ?: emptySet())

    fun isLocked(context: Context, packageName: String): Boolean =
        getLockedPackages(context).contains(packageName)

    fun setLocked(context: Context, packageName: String, locked: Boolean) {
        val current = getLockedPackages(context)
        if (locked) current.add(packageName) else current.remove(packageName)
        regularPrefs(context).edit().putStringSet(KEY_LOCKED_PACKAGES, current).apply()
    }

    // ---------- PIN management ----------

    fun hasPin(context: Context): Boolean =
        securePrefs(context).getString(KEY_PIN_HASH, null) != null

    fun setPin(context: Context, pin: String) {
        securePrefs(context).edit().putString(KEY_PIN_HASH, hash(pin)).apply()
    }

    fun checkPin(context: Context, pin: String): Boolean {
        val stored = securePrefs(context).getString(KEY_PIN_HASH, null) ?: return false
        return stored == hash(pin)
    }

    private fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(("applock_salt_" + pin).toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    // ---------- Grace period after unlocking ----------

    fun markUnlocked(context: Context, packageName: String) {
        regularPrefs(context).edit()
            .putLong(KEY_UNLOCK_UNTIL_PREFIX + packageName, System.currentTimeMillis() + GRACE_PERIOD_MS)
            .apply()
    }

    fun isWithinGracePeriod(context: Context, packageName: String): Boolean {
        val until = regularPrefs(context).getLong(KEY_UNLOCK_UNTIL_PREFIX + packageName, 0L)
        return System.currentTimeMillis() < until
    }
}
