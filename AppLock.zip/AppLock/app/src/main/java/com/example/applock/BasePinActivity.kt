package com.example.applock

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Wires up the 4-dot indicator and numeric keypad from activity_pin.xml.
 * Subclasses just implement onPinComplete(pin) and decide what to do with it.
 */
abstract class BasePinActivity : AppCompatActivity() {

    private lateinit var dots: List<android.view.View>
    private lateinit var pinError: TextView
    protected lateinit var pinTitle: TextView
    protected lateinit var pinSubtitle: TextView
    protected lateinit var backLink: TextView

    private val buffer = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pin)

        pinTitle = findViewById(R.id.pinTitle)
        pinSubtitle = findViewById(R.id.pinSubtitle)
        pinError = findViewById(R.id.pinError)
        backLink = findViewById(R.id.backLink)

        dots = listOf(
            findViewById(R.id.dot0),
            findViewById(R.id.dot1),
            findViewById(R.id.dot2),
            findViewById(R.id.dot3)
        )

        val keyIds = listOf(
            R.id.key1, R.id.key2, R.id.key3,
            R.id.key4, R.id.key5, R.id.key6,
            R.id.key7, R.id.key8, R.id.key9
        )
        keyIds.forEachIndexed { index, id ->
            findViewById<Button>(id).setOnClickListener { onDigit((index + 1).toString()) }
        }
        findViewById<Button>(R.id.key0).setOnClickListener { onDigit("0") }
        findViewById<Button>(R.id.keyDel).setOnClickListener { onDelete() }

        backLink.setOnClickListener { onBackLinkClicked() }
    }

    private fun onDigit(digit: String) {
        if (buffer.length >= 4) return
        clearError()
        buffer.append(digit)
        refreshDots(isError = false)
        if (buffer.length == 4) {
            val pin = buffer.toString()
            dots.last().postDelayed({ onPinComplete(pin) }, 120)
        }
    }

    private fun onDelete() {
        if (buffer.isNotEmpty()) {
            buffer.deleteCharAt(buffer.length - 1)
            refreshDots(isError = false)
        }
    }

    protected fun resetBuffer() {
        buffer.clear()
        refreshDots(isError = false)
    }

    protected fun showError(message: String) {
        pinError.text = message
        pinError.visibility = android.view.View.VISIBLE
        refreshDots(isError = true)
        pinError.postDelayed({
            buffer.clear()
            refreshDots(isError = false)
        }, 450)
    }

    private fun clearError() {
        pinError.visibility = android.view.View.INVISIBLE
    }

    private fun refreshDots(isError: Boolean) {
        for (i in dots.indices) {
            val filled = i < buffer.length
            dots[i].setBackgroundResource(
                when {
                    isError -> R.drawable.dot_error
                    filled -> R.drawable.dot_filled
                    else -> R.drawable.dot_empty
                }
            )
        }
    }

    /** Called once the user has entered 4 digits. */
    protected abstract fun onPinComplete(pin: String)

    /** Called when the "back / cancel" text link is tapped. */
    protected abstract fun onBackLinkClicked()
}
