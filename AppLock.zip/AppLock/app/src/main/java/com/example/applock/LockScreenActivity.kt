package com.example.applock

import android.app.Activity
import android.content.Intent
import android.os.Bundle

class LockScreenActivity : BasePinActivity() {

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_LOCKED_PACKAGE = "extra_locked_package"
        const val EXTRA_PACKAGE_LABEL = "extra_package_label"

        // Shown on top of a locked app; correct PIN just dismisses this screen
        const val MODE_UNLOCK_APP = "unlock_app"

        // Used from MainActivity to confirm the PIN before turning a lock off;
        // does not grant a grace-period unlock, just returns RESULT_OK
        const val MODE_CONFIRM_ONLY = "confirm_only"
    }

    private var mode: String = MODE_UNLOCK_APP
    private var lockedPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_UNLOCK_APP
        lockedPackage = intent.getStringExtra(EXTRA_LOCKED_PACKAGE)
        val label = intent.getStringExtra(EXTRA_PACKAGE_LABEL) ?: "এই অ্যাপ"

        pinTitle.text = "$label লক করা আছে"
        pinSubtitle.text = "খুলতে আপনার PIN দিন"
        backLink.text = if (mode == MODE_CONFIRM_ONLY) "← বাতিল করুন" else "← হোমে ফিরুন"
    }

    // Prevent dismissing the lock screen with the system back gesture/button
    override fun onBackPressed() {
        if (mode == MODE_UNLOCK_APP) {
            goHome()
        } else {
            setResult(Activity.RESULT_CANCELED)
            super.onBackPressed()
        }
    }

    override fun onPinComplete(pin: String) {
        if (PrefsHelper.checkPin(this, pin)) {
            if (mode == MODE_UNLOCK_APP && lockedPackage != null) {
                PrefsHelper.markUnlocked(this, lockedPackage!!)
            }
            setResult(Activity.RESULT_OK)
            finish()
        } else {
            showError("ভুল PIN, আবার চেষ্টা করুন")
        }
    }

    override fun onBackLinkClicked() {
        if (mode == MODE_UNLOCK_APP) {
            goHome()
        } else {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        setResult(Activity.RESULT_CANCELED)
        finish()
    }
}
