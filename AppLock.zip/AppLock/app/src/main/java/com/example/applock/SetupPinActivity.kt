package com.example.applock

import android.app.Activity
import android.os.Bundle

class SetupPinActivity : BasePinActivity() {

    private var firstPin: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pinTitle.text = "নতুন PIN তৈরি করুন"
        pinSubtitle.text = "৪ সংখ্যার একটি PIN দিন"
        backLink.text = "← বাতিল করুন"
    }

    override fun onPinComplete(pin: String) {
        val first = firstPin
        if (first == null) {
            // First entry done — ask them to confirm it
            firstPin = pin
            resetBuffer()
            pinTitle.text = "PIN আবার লিখুন"
            pinSubtitle.text = "নিশ্চিত করতে একই PIN আবার দিন"
        } else {
            if (pin == first) {
                PrefsHelper.setPin(this, pin)
                setResult(Activity.RESULT_OK)
                finish()
            } else {
                showError("PIN মিলছে না, আবার চেষ্টা করুন")
                firstPin = null
                pinTitle.text = "নতুন PIN তৈরি করুন"
                pinSubtitle.text = "৪ সংখ্যার একটি PIN দিন"
            }
        }
    }

    override fun onBackLinkClicked() {
        setResult(Activity.RESULT_CANCELED)
        finish()
    }
}
