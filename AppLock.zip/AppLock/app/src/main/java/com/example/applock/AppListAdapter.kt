package com.example.applock

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import androidx.recyclerview.widget.RecyclerView

class AppListAdapter(
    private val apps: List<AppInfo>,
    private val isLocked: (String) -> Boolean,
    // Called when the user flips a switch. Return true to accept the change immediately,
    // or false if a flow (like PIN setup) needs to happen first — in that case the adapter
    // will NOT change the switch state itself; the caller updates it later via notifyItemChanged.
    private val onToggle: (AppInfo, Boolean) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    class ViewHolder(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.appIcon)
        val name: TextView = view.findViewById(R.id.appName)
        val status: TextView = view.findViewById(R.id.appStatus)
        val toggle: SwitchCompat = view.findViewById(R.id.lockSwitch)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.icon.setImageDrawable(app.icon)
        holder.name.text = app.label

        val locked = isLocked(app.packageName)
        holder.status.text = if (locked) "লক করা আছে" else "লক নেই"

        // Avoid the listener firing while we're just setting the initial state
        holder.toggle.setOnCheckedChangeListener(null)
        holder.toggle.isChecked = locked
        holder.toggle.setOnCheckedChangeListener { _, isChecked ->
            onToggle(app, isChecked)
        }
    }

    override fun getItemCount(): Int = apps.size
}
