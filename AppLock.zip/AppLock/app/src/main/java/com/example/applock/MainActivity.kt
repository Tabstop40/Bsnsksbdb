package com.example.applock

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var permissionBanner: com.google.android.material.card.MaterialCardView
    private var apps: List<AppInfo> = emptyList()
    private var adapter: AppListAdapter? = null

    // Package name we're currently waiting on a PIN result for
    private var pendingPackage: String? = null

    private val setupPinLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pkg = pendingPackage
        pendingPackage = null
        if (result.resultCode == RESULT_OK && pkg != null) {
            PrefsHelper.setLocked(this, pkg, true)
        }
        adapter?.notifyDataSetChanged()
    }

    private val confirmPinLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val pkg = pendingPackage
        pendingPackage = null
        if (result.resultCode == RESULT_OK && pkg != null) {
            PrefsHelper.setLocked(this, pkg, false)
        }
        adapter?.notifyDataSetChanged()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.appRecyclerView)
        permissionBanner = findViewById(R.id.permissionBanner)
        findViewById<Button>(R.id.grantPermissionButton).setOnClickListener {
            openPermissionSettings()
        }

        apps = loadInstalledApps()
        adapter = AppListAdapter(
            apps = apps,
            isLocked = { pkg -> PrefsHelper.isLocked(this, pkg) },
            onToggle = { app, wantsLocked -> handleToggle(app, wantsLocked) }
        )
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        updatePermissionBanner()
        adapter?.notifyDataSetChanged()
    }

    private fun handleToggle(app: AppInfo, wantsLocked: Boolean) {
        if (wantsLocked) {
            if (!PrefsHelper.hasPin(this)) {
                // First time locking anything: set up a PIN first
                pendingPackage = app.packageName
                val intent = Intent(this, SetupPinActivity::class.java)
                setupPinLauncher.launch(intent)
            } else {
                PrefsHelper.setLocked(this, app.packageName, true)
                adapter?.notifyDataSetChanged()
            }
        } else {
            // Turning a lock off requires confirming the existing PIN
            pendingPackage = app.packageName
            val intent = Intent(this, LockScreenActivity::class.java).apply {
                putExtra(LockScreenActivity.EXTRA_MODE, LockScreenActivity.MODE_CONFIRM_ONLY)
                putExtra(LockScreenActivity.EXTRA_PACKAGE_LABEL, app.label)
            }
            confirmPinLauncher.launch(intent)
        }
    }

    private fun loadInstalledApps(): List<AppInfo> {
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(mainIntent, PackageManager.MATCH_ALL)
        return resolved
            .filter { it.activityInfo.packageName != packageName } // don't show App Lock itself
            .map {
                AppInfo(
                    packageName = it.activityInfo.packageName,
                    label = it.loadLabel(pm).toString(),
                    icon = it.loadIcon(pm)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    private fun updatePermissionBanner() {
        val needsOverlay = !Settings.canDrawOverlays(this)
        val needsAccessibility = !isAccessibilityServiceEnabled()
        permissionBanner.visibility =
            if (needsOverlay || needsAccessibility) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponent = "$packageName/${AppLockAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledServices.split(":").any { it.equals(expectedComponent, ignoreCase = true) }
    }

    private fun openPermissionSettings() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        } else if (!isAccessibilityServiceEnabled()) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }
}
