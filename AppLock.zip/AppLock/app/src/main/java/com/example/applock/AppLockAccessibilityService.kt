package com.example.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class AppLockAccessibilityService : AccessibilityService() {

    // Avoids re-launching the lock screen repeatedly for the same foreground event spam
    private var lastPromptedPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val packageName = event.packageName?.toString() ?: return

        // Ignore our own UI (the lock screen and setup screens)
        if (packageName == applicationContext.packageName) {
            return
        }

        if (packageName != lastPromptedPackage) {
            lastPromptedPackage = null
        }

        if (!PrefsHelper.isLocked(this, packageName)) return
        if (PrefsHelper.isWithinGracePeriod(this, packageName)) return
        if (packageName == lastPromptedPackage) return

        lastPromptedPackage = packageName
        showLockScreen(packageName)
    }

    private fun showLockScreen(packageName: String) {
        val label = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(packageName, 0)).toString()
        } catch (e: Exception) {
            packageName
        }

        val intent = Intent(this, LockScreenActivity::class.java).apply {
            putExtra(LockScreenActivity.EXTRA_MODE, LockScreenActivity.MODE_UNLOCK_APP)
            putExtra(LockScreenActivity.EXTRA_LOCKED_PACKAGE, packageName)
            putExtra(LockScreenActivity.EXTRA_PACKAGE_LABEL, label)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(intent)
    }

    override fun onInterrupt() { /* no-op */ }
}
